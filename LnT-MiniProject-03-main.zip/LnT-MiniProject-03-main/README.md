# Mini Project #03 - Dockerized To-Do API

## Project Overview

This project demonstrates how to build, containerize, and deploy a RESTful To-Do API using Python Flask and Docker.

The application provides CRUD (Create, Read, Update, Delete) operations for managing tasks and is packaged into a Docker image using a multi-stage Docker build. The image is versioned using Semantic Versioning and published to Docker Hub.

---

## Objectives

* Build a REST API using Flask
* Implement CRUD operations
* Containerize the application using Docker
* Use a multi-stage Dockerfile to reduce image size
* Push the image to Docker Hub
* Follow Semantic Versioning practices

---

## Technology Stack

* Python 3
* Flask
* Docker
* Docker Hub
* Git & GitHub

---

## Project Structure

```text
todo-api/
│
├── app.py
├── requirements.txt
├── Dockerfile
├── .dockerignore
└── README.md
```

---

## API Endpoints

### Home

```http
GET /
```

Response:

```json
{
  "message": "Todo API Running"
}
```

### Create Task

```http
POST /todos
```

Request Body:

```json
{
  "task": "Learn Docker"
}
```

### Get All Tasks

```http
GET /todos
```

### Update Task

```http
PUT /todos/<id>
```

### Delete Task

```http
DELETE /todos/<id>
```

---

## Running the Application Locally

Install dependencies:

```bash
pip install -r requirements.txt
```

Start the application:

```bash
python app.py
```

Open:

```text
http://localhost:5000
```

---

## Docker Build

Build the Docker image:

```bash
docker build -t todo-api:v1.0.0 .
```

Verify image:

```bash
docker images
```

---

## Run Docker Container

```bash
docker run -p 5000:5000 todo-api:v1.0.0
```

Application URL:

```text
http://localhost:5000
```

---

## Docker Hub

Pull the published image:

```bash
docker pull sarthzz01/todo-api:v1.0.0
```

Run the image:

```bash
docker run -p 5000:5000 sarthzz01/todo-api:v1.0.0
```

---

## Semantic Versioning

This project follows Semantic Versioning:

```text
MAJOR.MINOR.PATCH
```

Examples:

```text
v1.0.0
v1.0.1
v1.1.0
v2.0.0
```

---

## Learning Outcomes

* REST API Development
* CRUD Operations
* Docker Fundamentals
* Multi-Stage Docker Builds
* Docker Image Management
* Docker Hub Publishing
* Version Control using Git

---

## Author

Sarthak Kane

DevOps & Cloud Computing Learner
