from flask import Flask, request, jsonify

app = Flask(__name__)

todos = []

@app.route('/')
def home():
    return jsonify({"message":"Todo API Running"})

# CREATE
@app.route('/todos', methods=['POST'])
def create_todo():
    data = request.json
    todos.append(data)
    return jsonify(data), 201

# READ
@app.route('/todos', methods=['GET'])
def get_todos():
    return jsonify(todos)

# UPDATE
@app.route('/todos/<int:index>', methods=['PUT'])
def update_todo(index):
    if index >= len(todos):
        return jsonify({"error":"Not Found"}),404

    todos[index] = request.json
    return jsonify(todos[index])

# DELETE
@app.route('/todos/<int:index>', methods=['DELETE'])
def delete_todo(index):
    if index >= len(todos):
        return jsonify({"error":"Not Found"}),404

    deleted = todos.pop(index)
    return jsonify(deleted)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)