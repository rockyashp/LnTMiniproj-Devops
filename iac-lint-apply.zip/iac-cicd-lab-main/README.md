# LintGate - IAC CICD Lab

A Terraform infrastructure-as-code project with automated linting and validation via GitHub Actions CI/CD.

## Quick Start

### Prerequisites
- Terraform >= 1.0
- Git
- GitHub account (for CI/CD workflows)

### Setup
```bash
# Clone the repository
git clone <repo-url>
cd iac-cicd-lab

# Initialize Terraform (local mode)
terraform init -backend=false

# Format check
terraform fmt -check -recursive

# Validate configuration
terraform validate

# Plan changes
terraform plan

# Apply configuration
terraform apply
```

## Project Structure
```
iac-cicd-lab/
├── main.tf              # Core Terraform configuration
├── .github/workflows/
│   └── lint.yaml       # Automated CI/CD pipeline
├── .gitignore          # Git exclusions
├── .terraform/         # Terraform working directory
└── README.md           # This file
```

## How It Works

### Local Development
1. **Format Check**: Ensure code follows Terraform conventions
   ```bash
   terraform fmt -recursive
   ```
2. **Initialize**: Prepare working directory
   ```bash
   terraform init -backend=false
   ```
3. **Validate**: Check syntax and configuration
   ```bash
   terraform validate
   ```
4. **Plan**: Preview infrastructure changes
   ```bash
   terraform plan
   ```

### CI/CD Pipeline (GitHub Actions)
The `.github/workflows/lint.yaml` workflow automatically runs on pull requests to `main`:
- ✅ Terraform format validation
- ✅ Configuration syntax validation
- ✅ Terraform validation check

**Trigger**: Push to PR against `main` branch  
**Status**: Check GitHub Actions tab for results

## Important Things to Look For

| Issue | Solution |
|-------|----------|
| **Format errors** | Run `terraform fmt -recursive` before commit |
| **Validation fails** | Check required providers and resource syntax in `main.tf` |
| **State conflicts** | Use `-backend=false` for local development to avoid state issues |
| **Provider mismatch** | Verify `hashicorp/local` provider version matches `~>2.5` |
| **Path issues** | Use `${path.module}` for relative file paths in resources |

## To-Do / Next Steps

- [ ] Add remote state backend configuration (AWS S3 + DynamoDB)
- [ ] Implement input variables (`variables.tf`)
- [ ] Add outputs file (`outputs.tf`)
- [ ] Create separate environments (dev/prod)
- [ ] Add security scanning (tfsec) to CI/CD
- [ ] Document resource dependencies
- [ ] Set up Terraform Cloud/Enterprise integration
- [ ] Add cost estimation to CI/CD pipeline
- [ ] Create module structure for reusability
- [ ] Add pre-commit hooks for local validation

## Current Configuration

**Resources**:
- `local_file.student_doc`: Creates a test file demonstrating Terraform basics

**Outputs**:
- `test`: Returns "hello" string for validation

## Troubleshooting

**Terraform init fails?**
```bash
# Ensure backend is disabled for local testing
terraform init -backend=false

# Or clear state
rm -rf .terraform .terraform.lock.hcl
```

**CI/CD workflow not running?**
- Check `.github/workflows/lint.yaml` syntax
- Verify branch name matches trigger condition (`main`)
- Confirm workflow file is in correct directory

**Provider installation issues?**
```bash
# Reinstall providers
rm -rf .terraform
terraform init -backend=false
```

## Resources
- [Terraform Documentation](https://www.terraform.io/docs)
- [HashiCorp Local Provider](https://registry.terraform.io/providers/hashicorp/local/latest)
- [GitHub Actions CI/CD](https://docs.github.com/en/actions)
